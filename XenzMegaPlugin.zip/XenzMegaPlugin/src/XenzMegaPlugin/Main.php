<?php

namespace XenzMegaPlugin;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\utils\Config;

class Main extends PluginBase implements Listener {

    private $homes;
    private $economy;

    public function onEnable() {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        @mkdir($this->getDataFolder());
        $this->homes = new Config($this->getDataFolder() . "homes.yml", Config::YAML);
        $this->economy = new Config($this->getDataFolder() . "economy.yml", Config::YAML);
        $this->getLogger()->info("XenzMegaPlugin enabled!");
    }

    public function onJoin(PlayerJoinEvent $event) {
        $player = $event->getPlayer();
        $name = strtolower($player->getName());
        if(!$this->economy->exists($name)) {
            $this->economy->set($name, 1000); // start with 1000 money
            $this->economy->save();
        }
        $player->sendMessage("Welcome to XenzMegaPlugin server! You have " . $this->economy->get($name) . " coins.");
    }

    public function onCommand(CommandSender $sender, Command $cmd, string $label, array $args): bool {
        if(!$sender instanceof Player) {
            $sender->sendMessage("Only players can use commands!");
            return true;
        }

        $name = strtolower($sender->getName());

        switch(strtolower($cmd->getName())) {
            case "sethome":
                $this->homes->set($name, $sender->getPosition());
                $this->homes->save();
                $sender->sendMessage("Home set!");
                return true;

            case "home":
                if(!$this->homes->exists($name)) {
                    $sender->sendMessage("You have no home set!");
                    return true;
                }
                $pos = $this->homes->get($name);
                $sender->teleport($pos);
                $sender->sendMessage("Teleported to home.");
                return true;

            case "balance":
                $bal = $this->economy->get($name);
                $sender->sendMessage("Your balance: $bal coins");
                return true;

            case "pay":
                if(count($args) < 2) {
                    $sender->sendMessage("Usage: /pay <player> <amount>");
                    return true;
                }
                $targetName = strtolower($args[0]);
                $amount = (int)$args[1];
                if($amount <= 0) {
                    $sender->sendMessage("Amount must be positive!");
                    return true;
                }
                if(!$this->economy->exists($targetName)) {
                    $sender->sendMessage("Player not found!");
                    return true;
                }
                $bal = $this->economy->get($name);
                if($bal < $amount) {
                    $sender->sendMessage("Insufficient funds!");
                    return true;
                }
                $this->economy->set($name, $bal - $amount);
                $targetBal = $this->economy->get($targetName);
                $this->economy->set($targetName, $targetBal + $amount);
                $this->economy->save();
                $sender->sendMessage("You paid $amount coins to $targetName");
                $target = $this->getServer()->getPlayerExact($args[0]);
                if($target !== null) {
                    $target->sendMessage("You received $amount coins from $name");
                }
                return true;

            case "broadcast":
                if(!$sender->isOp()) {
                    $sender->sendMessage("You are not OP!");
                    return true;
                }
                if(count($args) < 1) {
                    $sender->sendMessage("Usage: /broadcast <message>");
                    return true;
                }
                $msg = implode(" ", $args);
                $this->getServer()->broadcastMessage("[Broadcast] $msg");
                return true;

            default:
                return false;
        }
    }

}